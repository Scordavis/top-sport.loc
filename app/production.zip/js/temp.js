// $(function() {

	// Custom JS

	// insert slider img src to background-image

	// var arr = $('.gallery_item');
	// arr.each(function( i, el) {
	// var bgSrc = $(this).find('.js-image').attr('src');
	//  $(this).find('.js-background').css('background-image', 'url("' + bgSrc + '")');
	// });

	// $(this).find(".gallery__item")(function(){
	// 	var bgSrc = $('.gallery__item > .js-background > .js-image').attr('src');
	// 	 $('.gallery__item > .js-background').css('background-image', 'url("' + bgSrc + '")');
	// });


	// var bgSrc = $('.js-image').attr('src');
	// $('.js-background').css('background-image', 'url("' + bgSrc + '")');

	// });
